import React, { useState } from "react";

export default function App() {
  const [foods, setFoods] = useState([]);
  const [foodName, setFoodName] = useState("");
  const [foodCalories, setFoodCalories] = useState("");
  const [dailyCalories, setDailyCalories] = useState(0);
  const [goal, setGoal] = useState(0);
  const [weight, setWeight] = useState(100);
  const [objective, setObjective] = useState("manter");

  const addFood = () => {
    if (!foodName || !foodCalories) return;
    const calories = parseInt(foodCalories);
    setFoods([...foods, { name: foodName, calories }]);
    setDailyCalories(dailyCalories + calories);
    setFoodName("");
    setFoodCalories("");
  };

  const calculateGoal = () => {
    let base = weight * 22;
    if (objective === "emagrecer") base -= 500;
    if (objective === "ganhar") base += 500;
    setGoal(base);
  };

  return (
    <div style={{ maxWidth: 400, margin: "0 auto", fontFamily: "sans-serif" }}>
      <h1 style={{ color: "#2196f3" }}>Contador de Calorias</h1>
      <div style={{ marginBottom: 20 }}>
        <label>Peso (kg)</label>
        <input type="number" value={weight} onChange={e => setWeight(e.target.value)} />
        <label>Objetivo</label>
        <select value={objective} onChange={e => setObjective(e.target.value)}>
          <option value="manter">Manter peso</option>
          <option value="emagrecer">Emagrecer</option>
          <option value="ganhar">Ganhar peso</option>
        </select>
        <button style={{ background: "#2196f3", color: "#fff" }} onClick={calculateGoal}>Calcular Meta</button>
        {goal > 0 && <p>Meta diária: {goal} kcal</p>}
      </div>

      <div>
        <h2>Adicionar alimento</h2>
        <input type="text" placeholder="Nome do alimento" value={foodName} onChange={e => setFoodName(e.target.value)} />
        <input type="number" placeholder="Calorias" value={foodCalories} onChange={e => setFoodCalories(e.target.value)} />
        <button style={{ background: "green", color: "#fff" }} onClick={addFood}>Adicionar</button>
      </div>

      <div style={{ marginTop: 20 }}>
        <h2>Refeições do dia</h2>
        <ul>
          {foods.map((f, i) => <li key={i}>{f.name} - {f.calories} kcal</li>)}
        </ul>
        <p>Total: {dailyCalories} kcal</p>
      </div>
    </div>
  );
}